#!/bin/bash

mysql_install_db --user=mysql
sleep 3
mysqld_safe &
sleep 3
mysql -e "use mysql;grant all privileges on *.* to root@'%' identified by 'a1b2c3d4f5' with grant option;flush privileges;"
sleep 3
mysqladmin -u root password 'a1b2c3d4f5'
