#!/bin/bash
cd /usr/share/nginx/html
git init

git config --global user.email "h0k@example.com"
git config --global user.name "h0k"


git add info.php
git add index.html
git add initmysql.sh 
git commit -m "for test"


