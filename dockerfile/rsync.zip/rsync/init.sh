#!/bin/bash

mkdir /var/log/rsync

useradd rsync -s /sbin/nologin -M
sleep 3
mkdir /backup
sleep 3
chown rsync.rsync /backup/

#echo "/usr/bin/rsync --daemon" >>/etc/rc.local


